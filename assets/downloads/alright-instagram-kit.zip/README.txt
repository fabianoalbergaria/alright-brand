Alright · Instagram Kit v3 (2026-05-26)
========================================

Conteúdo:

/psd/ — 16 PSDs editáveis com text layers vetoriais
    avatar-a-symbol.psd       1080×1080  Avatar com símbolo 3 figuras
    avatar-b-favicon.psd      1080×1080  Avatar com lockup
    avatar-c-wordmark.psd     1080×1080  Avatar wordmark

    feed-01-case.psd          1080×1350  Capa caso (Eyebrow, Index, Title, Meta)
    feed-02-manifesto.psd     1080×1350  Manifesto (Kicker x2, Quote, Tag)
    feed-03-bigidea.psd       1080×1350  Big idea (Kicker x2, Phrase, Tag)
    feed-04-making-of.psd     1080×1350  Making-of (Eyebrow, Ref, Frame tag, Title, Meta)
    feed-05-quote.psd         1080×1350  Quote (Kicker x2, Body, Attrib, Meta)
    feed-06-split.psd         1080×1350  Split (Eyebrow, Headline, Lead, Meta)

    feed-09-h-case.psd        1080×608   Case landscape 16:9
    feed-10-h-bigidea.psd     1080×608   Big idea landscape 16:9
    feed-11-h-quote.psd       1080×608   Quote landscape 16:9
    feed-12-h-making-of.psd   1080×608   Making-of landscape 16:9
    feed-13-h-split.psd       1080×608   Split landscape 16:9

    vertical-07-reels-cover.psd  1080×1920  Reels cover (Eyebrow, Ref, Title)
    vertical-08-stories.psd      1080×1920  Stories (Index, Headline, Lead, CTA)

/png/ — Previews PNG renderizados
    avatar-a-symbol.png       Avatar A · símbolo
    avatar-b-favicon.png      Avatar B · lockup
    avatar-c-wordmark.png     Avatar C · wordmark

Como usar os PSDs:
==================

Cada PSD tem 3 grupos de layers:

1. Background (raster)
   Cor sólida ou split panes. NÃO mexer — é a tela.

2. Brand · decor (raster)
   Decorações canon (accent bars, etc). NÃO mexer.

3. Text layers vetoriais (uma por elemento editável)
   Double-click no thumbnail no Photoshop pra editar texto, fonte,
   cor, posição. Fontes Monument Grotesk e Neue Haas Display Bold
   precisam estar instaladas em ~/Library/Fonts/.

4. Wordmark · Dark / Bone / Orange (3 image layers stacked)
   1 visível conforme bg da peça, 2 hidden. Toggle visibility
   pra trocar cor do wordmark sem mexer no resto.

Fontes (incluídas em /assets/fonts/v3/ no repo)
===============================================

- Monument Grotesk (Regular, Medium, Bold, Mono)
- Neue Haas Display (Roman, Medium, Bold, Black, Light, Thin)

Instalar em ~/Library/Fonts/ antes de abrir os PSDs no Photoshop.

Editor online
=============

Versão online com edits inline + download PNG/PDF/PSD em:
https://kit.wearealright.cc (precisa @wearealright.cc Cloudflare Access)

Brand: Alright · A.I. first Production Company · São Paulo / BR
((Look again.))
