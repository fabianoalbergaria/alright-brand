Alright — Favicon kit v3 (2026-05-26 rebrand)

Símbolo (3 figuras correndo com laptops) em preto sobre transparente,
exportado em 7 tamanhos:

  icon-16.png       — favicon padrão
  icon-32.png       — favicon retina
  icon-48.png       — Windows tile
  icon-64.png       — Windows tile large
  apple-touch-icon.png (180×180) — iOS home screen
  icon-192.png      — Android home screen
  icon-512.png      — PWA splash / high-DPI

Recomendado sobre Black puro (#000000) ou Bone (#faf9f5).
Para variante laranja, use Symbol_Orange (Orange Alright #FF5D36).

((We Are Alright))
